#!/bin/bash

python -m unittest discover -p '*test.py' -v
